package com.movieproject.MovieProject.controller;

import org.springframework.stereotype.Controller;

@Controller
public class FavoritoController {
}
