package com.movieproject.MovieProject.model;

public class Avaliacao {
}
