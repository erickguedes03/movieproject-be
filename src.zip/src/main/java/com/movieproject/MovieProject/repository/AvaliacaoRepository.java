package com.movieproject.MovieProject.repository;

public class AvaliacaoRepository {
}
