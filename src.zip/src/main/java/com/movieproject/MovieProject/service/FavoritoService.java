package com.movieproject.MovieProject.service;

import org.springframework.stereotype.Service;

@Service
public class FavoritoService {
}
